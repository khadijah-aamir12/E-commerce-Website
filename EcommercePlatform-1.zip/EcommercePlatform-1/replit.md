# E-commerce Application

## Overview

This is a full-stack e-commerce application built with React, Express.js, and PostgreSQL. The application provides a complete shopping experience with user authentication, product catalog, shopping cart, and order management functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state, React Context for cart state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: PostgreSQL-based session storage
- **API Design**: RESTful endpoints with proper error handling

## Key Components

### Authentication System
- **Provider**: Replit Auth using OpenID Connect
- **Session Storage**: PostgreSQL table with connect-pg-simple
- **Authorization**: Route-level authentication middleware
- **User Management**: Automatic user creation/updates on login

### Database Schema
- **Users**: Profile information (required for Replit Auth)
- **Categories**: Product categorization
- **Products**: Full product catalog with images, pricing, and metadata
- **Cart Items**: User shopping cart persistence
- **Orders & Order Items**: Order history and transaction records
- **Reviews**: Product review system
- **Sessions**: Authentication session storage (required for Replit Auth)

### Product Management
- **Catalog**: Full product browsing with search and filtering
- **Categories**: Hierarchical product organization
- **Search**: Text-based product search functionality
- **Filtering**: Category-based and feature-based filtering (featured, on sale)

### Shopping Cart
- **Persistence**: Server-side cart storage for authenticated users
- **Real-time Updates**: Optimistic updates with React Query
- **Quantity Management**: Add, remove, and update item quantities
- **Cross-session**: Cart persists across browser sessions

### Order Processing
- **Checkout**: Multi-step checkout process with form validation
- **Payment**: Placeholder payment integration ready for external processors
- **Order History**: Complete order tracking for users
- **Inventory**: Basic inventory management concepts

## Data Flow

1. **User Authentication**: Users authenticate via Replit Auth, creating/updating user records
2. **Product Browsing**: Frontend fetches products from REST API with optional filters
3. **Cart Management**: All cart operations sync with backend, maintaining persistence
4. **Order Processing**: Checkout creates orders and order items, clearing cart
5. **Session Management**: PostgreSQL sessions maintain user state across requests

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit Auth service
- **UI Library**: Radix UI primitives via shadcn/ui
- **State Management**: TanStack Query for server state
- **Validation**: Zod for runtime type checking and validation

### Development Tools
- **ORM**: Drizzle with PostgreSQL dialect
- **Build**: Vite with React plugin
- **TypeScript**: Full type safety across frontend and backend
- **CSS**: Tailwind CSS with PostCSS processing

## Deployment Strategy

### Development
- **Server**: tsx for TypeScript execution in development
- **Frontend**: Vite dev server with HMR
- **Database**: Drizzle migrations via `db:push` command
- **Environment**: Requires DATABASE_URL and Replit Auth configuration

### Production
- **Build Process**: 
  - Frontend: Vite build to `dist/public`
  - Backend: esbuild bundle to `dist/index.js`
- **Deployment**: Single Node.js process serving both API and static files
- **Database**: PostgreSQL with connection pooling via Neon serverless

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `SESSION_SECRET`: Session encryption key (required)
- `REPL_ID`: Replit environment identifier (required for auth)
- `ISSUER_URL`: OpenID Connect issuer URL (optional, defaults to Replit)
- `REPLIT_DOMAINS`: Allowed domains for OIDC (required)

The application follows a monorepo structure with shared TypeScript types and schemas, enabling type safety across the full stack while maintaining clear separation between frontend and backend concerns.