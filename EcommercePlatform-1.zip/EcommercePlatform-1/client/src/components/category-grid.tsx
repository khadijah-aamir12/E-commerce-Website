import { useLocation } from "wouter";
import type { Category } from "@shared/schema";

interface CategoryGridProps {
  categories: Category[];
}

export default function CategoryGrid({ categories }: CategoryGridProps) {
  const [, setLocation] = useLocation();

  const defaultCategories = [
    { id: 1, name: "Electronics", imageUrl: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=300&fit=crop" },
    { id: 2, name: "Fashion", imageUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=300&fit=crop" },
    { id: 3, name: "Home & Garden", imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop" },
    { id: 4, name: "Sports", imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop" },
    { id: 5, name: "Books", imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=300&fit=crop" },
    { id: 6, name: "Beauty", imageUrl: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=400&h=300&fit=crop" },
  ];

  const displayCategories = categories.length > 0 ? categories : defaultCategories;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
      {displayCategories.map((category) => (
        <div
          key={category.id}
          className="text-center group cursor-pointer"
          onClick={() => setLocation(`/products?category=${category.id}`)}
        >
          <div className="bg-gray-100 rounded-2xl p-6 mb-4 group-hover:bg-gray-200 transition-colors">
            <img
              src={category.imageUrl || "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400&h=300&fit=crop"}
              alt={`${category.name} category`}
              className="w-full h-16 object-cover rounded-lg mb-2"
            />
            <h3 className="font-semibold text-gray-800">{category.name}</h3>
          </div>
        </div>
      ))}
    </div>
  );
}
