import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ShoppingBag, Shield, RotateCcw } from "lucide-react";

export default function HeroSection() {
  const [, setLocation] = useLocation();

  return (
    <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Discover Amazing Products
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Find everything you need with our curated selection of quality products at unbeatable prices.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => setLocation("/products")}
                className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 text-lg"
              >
                Shop Now
              </Button>
              <Button
                onClick={() => setLocation("/products")}
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 text-lg"
              >
                View Categories
              </Button>
            </div>
          </div>
          <div className="relative">
            <Card className="bg-white bg-opacity-10 backdrop-blur-sm border-white/20">
              <CardContent className="p-8">
                <ShoppingBag className="w-16 h-16 text-amber-400 mb-4" />
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm">✓</span>
                    </div>
                    <span>Free Shipping on Orders $50+</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Shield className="w-6 h-6 text-blue-300" />
                    <span>Secure Payment Processing</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <RotateCcw className="w-6 h-6 text-yellow-300" />
                    <span>30-Day Return Policy</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
