import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShoppingBag, User, MapPin, CreditCard, Heart } from "lucide-react";

export default function Account() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/orders'],
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-4 w-48" />
                </div>
              </CardContent>
            </Card>
            <div className="lg:col-span-3">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-24 w-full" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "shipped":
        return "bg-blue-100 text-blue-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "pending":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Account</h1>
          <p className="text-gray-600">Manage your account and order history</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  {user?.profileImageUrl ? (
                    <img
                      src={user.profileImageUrl}
                      alt="Profile"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <User className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold">
                    {user?.firstName} {user?.lastName}
                  </h3>
                  <p className="text-gray-600 text-sm">{user?.email}</p>
                </div>
              </div>
              
              <Tabs defaultValue="orders" className="w-full">
                <TabsList className="grid w-full grid-cols-1 h-auto">
                  <TabsTrigger value="orders" className="flex items-center space-x-2 py-3">
                    <ShoppingBag className="w-4 h-4" />
                    <span>My Orders</span>
                  </TabsTrigger>
                  <TabsTrigger value="profile" className="flex items-center space-x-2 py-3">
                    <User className="w-4 h-4" />
                    <span>Profile</span>
                  </TabsTrigger>
                  <TabsTrigger value="addresses" className="flex items-center space-x-2 py-3">
                    <MapPin className="w-4 h-4" />
                    <span>Addresses</span>
                  </TabsTrigger>
                  <TabsTrigger value="payment" className="flex items-center space-x-2 py-3">
                    <CreditCard className="w-4 h-4" />
                    <span>Payment</span>
                  </TabsTrigger>
                  <TabsTrigger value="wishlist" className="flex items-center space-x-2 py-3">
                    <Heart className="w-4 h-4" />
                    <span>Wishlist</span>
                  </TabsTrigger>
                </TabsList>

                {/* Main Content */}
                <div className="lg:col-span-3 ml-8">
                  <TabsContent value="orders">
                    <Card>
                      <CardHeader>
                        <CardTitle>Order History</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {ordersLoading ? (
                          <div className="space-y-4">
                            {Array.from({ length: 3 }).map((_, i) => (
                              <div key={i} className="border rounded-lg p-4">
                                <div className="flex items-center justify-between mb-4">
                                  <div>
                                    <Skeleton className="h-5 w-32 mb-2" />
                                    <Skeleton className="h-4 w-24" />
                                  </div>
                                  <Skeleton className="h-6 w-20" />
                                </div>
                                <div className="flex items-center space-x-4">
                                  <Skeleton className="w-16 h-16 rounded-lg" />
                                  <Skeleton className="h-6 w-48" />
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : orders && orders.length > 0 ? (
                          <div className="space-y-4">
                            {orders.map((order: any) => (
                              <div key={order.id} className="border rounded-lg p-4">
                                <div className="flex items-center justify-between mb-4">
                                  <div>
                                    <h3 className="font-semibold">Order #{order.id}</h3>
                                    <p className="text-gray-600 text-sm">
                                      {new Date(order.createdAt).toLocaleDateString()}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <Badge className={getStatusColor(order.status)}>
                                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                    </Badge>
                                    <p className="text-gray-600 text-sm mt-1">
                                      Total: ${order.total}
                                    </p>
                                  </div>
                                </div>
                                
                                {order.items && order.items.length > 0 && (
                                  <div className="space-y-2">
                                    {order.items.map((item: any) => (
                                      <div key={item.id} className="flex items-center space-x-4">
                                        <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden">
                                          <img
                                            src={item.product.imageUrl || "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=100&h=100&fit=crop"}
                                            alt={item.product.name}
                                            className="w-full h-full object-cover"
                                          />
                                        </div>
                                        <div className="flex-1">
                                          <h4 className="font-semibold">{item.product.name}</h4>
                                          <p className="text-gray-600 text-sm">
                                            Quantity: {item.quantity}
                                          </p>
                                        </div>
                                        <div className="flex space-x-2">
                                          <Button variant="outline" size="sm">
                                            View Details
                                          </Button>
                                          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                                            Buy Again
                                          </Button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <ShoppingBag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-600">No orders yet</p>
                            <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                              Start Shopping
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="profile">
                    <Card>
                      <CardHeader>
                        <CardTitle>Profile Information</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                First Name
                              </label>
                              <p className="text-gray-900">{user?.firstName || "Not provided"}</p>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Last Name
                              </label>
                              <p className="text-gray-900">{user?.lastName || "Not provided"}</p>
                            </div>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Email
                            </label>
                            <p className="text-gray-900">{user?.email || "Not provided"}</p>
                          </div>
                          <Button className="bg-blue-600 hover:bg-blue-700">
                            Edit Profile
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="addresses">
                    <Card>
                      <CardHeader>
                        <CardTitle>Saved Addresses</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-8">
                          <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">No saved addresses</p>
                          <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                            Add Address
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="payment">
                    <Card>
                      <CardHeader>
                        <CardTitle>Payment Methods</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-8">
                          <CreditCard className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">No payment methods saved</p>
                          <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                            Add Payment Method
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="wishlist">
                    <Card>
                      <CardHeader>
                        <CardTitle>Wishlist</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-8">
                          <Heart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">Your wishlist is empty</p>
                          <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                            Browse Products
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
